const router = require('express').Router();
const schemas = require('../validators');
const Tenant = require('../models/TenantEnquiry');
const Agent = require('../models/AgentEnquiry');
const { notify } = require('../mailer');

const handler = (schema, build, label) => async (req, res, next) => {
  try {
    // Honeypot filled: pretend success so bots learn nothing
    if (req.body && req.body.company_url) return res.status(201).json({ ok: true });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) {
      const errors = {};
      parsed.error.issues.forEach((i) => { errors[i.path[0]] ||= i.message; });
      return res.status(422).json({ ok: false, message: 'Please check the highlighted fields.', errors });
    }
    const d = parsed.data;
    // Time-trap: submissions under 3 seconds are almost certainly bots
    if (typeof d.startedAt === 'number' && Date.now() - d.startedAt < 3000) return res.status(201).json({ ok: true });
    const doc = await build(d, { ip: req.ip, userAgent: (req.get('user-agent') || '').slice(0, 250) });
    notify(`New ${label} enquiry: ${d.fullName}`, doc.toObject()).catch((e) => console.error('Mail failed:', e.message));
    res.status(201).json({ ok: true });
  } catch (e) { next(e); }
};

router.post('/tenant', handler(schemas.tenant, (d, meta) => Tenant.create({
  fullName: d.fullName, email: d.email, phone: d.phone, location: d.location, propertyType: d.propertyType,
  bedrooms: d.bedrooms, budgetGBP: d.budget, moveInDate: d.moveInDate, requirements: d.requirements,
  consentPrivacy: true, consentMarketing: d.consentMarketing, meta }), 'tenant'));

router.post('/agent', handler(schemas.agent, (d, meta) => Agent.create({
  fullName: d.fullName, agencyName: d.agencyName, email: d.email, phone: d.phone, website: d.website,
  location: d.location, agentType: d.agentType, areasCovered: d.areasCovered, info: d.info,
  consentPrivacy: true, consentMarketing: d.consentMarketing, meta }), 'agent'));

module.exports = router;
