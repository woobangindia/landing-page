const { Schema, model } = require('mongoose');
module.exports = model('AgentEnquiry', new Schema({
  fullName: { type: String, required: true, trim: true },
  agencyName: { type: String, required: true, trim: true },
  email: { type: String, required: true, lowercase: true, index: true },
  phone: { type: String, required: true },
  website: String,
  location: { type: String, required: true },
  agentType: { type: String, enum: ['Estate Agent', 'Letting Agent', 'Property Manager', 'Developer', 'Other'] },
  areasCovered: String,
  info: String,
  consentPrivacy: { type: Boolean, required: true },
  consentMarketing: { type: Boolean, default: false },
  consentAt: { type: Date, default: Date.now },
  status: { type: String, enum: ['new', 'contacted', 'closed'], default: 'new' },
  meta: { ip: String, userAgent: String },
}, { timestamps: true }));
