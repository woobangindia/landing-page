const { Schema, model } = require('mongoose');
module.exports = model('TenantEnquiry', new Schema({
  fullName: { type: String, required: true, trim: true },
  email: { type: String, required: true, lowercase: true, index: true },
  phone: { type: String, required: true },
  location: { type: String, required: true },
  propertyType: { type: String, enum: ['Apartment', 'Flat', 'House', 'Studio', 'Other'] },
  bedrooms: { type: String, enum: ['Studio', '1', '2', '3', '4', '5+'] },
  budgetGBP: { type: Number, min: 0 },
  moveInDate: Date,
  requirements: String,
  consentPrivacy: { type: Boolean, required: true },
  consentMarketing: { type: Boolean, default: false },
  consentAt: { type: Date, default: Date.now },
  status: { type: String, enum: ['new', 'contacted', 'closed'], default: 'new' },
  meta: { ip: String, userAgent: String },
}, { timestamps: true }));
