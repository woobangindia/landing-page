const nodemailer = require('nodemailer');
let transport;
async function notify(subject, fields) {
  if (!process.env.SMTP_HOST || !process.env.NOTIFY_TO) return; // disabled
  transport ||= nodemailer.createTransport({
    host: process.env.SMTP_HOST, port: +process.env.SMTP_PORT || 587,
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined });
  const text = Object.entries(fields).filter(([k, v]) => k !== 'meta' && v != null && v !== '')
    .map(([k, v]) => `${k}: ${v}`).join('\n');
  await transport.sendMail({ from: process.env.MAIL_FROM, to: process.env.NOTIFY_TO, subject, text });
}
module.exports = { notify };
