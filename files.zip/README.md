# Harbourline landing page (placeholder brand name)
Node/Express + MongoDB + static front end. Search/replace "Harbourline" and `example.co.uk` with your details.

    cp .env.example .env   # set MONGODB_URI (and SMTP_* to enable email notifications)
    npm install && npm start   # http://localhost:3000

**Images** (not bundled): add JPGs to `public/images/` as `hero|tenants|agents|about` + `-800.jpg` / `-1600.jpg`. Until then a navy placeholder shows.
**API**: `POST /api/enquiries/tenant`, `POST /api/enquiries/agent`, `GET /api/health`.
**Spam protection**: honeypot, 3s time-trap, rate limit (10 / 15 min / IP), 20kb body cap.
**TODO before launch**: Privacy/Terms/Cookie pages (`/privacy` etc.), real copy, domain in sitemap/robots/canonical/OG, cookie banner if you add analytics.
Layout is split into `server/routes`, `server/models`, `server/validators.js` so it can be mounted in a larger platform later.
