require('dotenv').config();
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const mongoose = require('mongoose');

const app = express();
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: { directives: {
  defaultSrc: ["'self'"], scriptSrc: ["'self'"], connectSrc: ["'self'"],
  styleSrc: ["'self'", 'https://fonts.googleapis.com'], fontSrc: ['https://fonts.gstatic.com'],
  imgSrc: ["'self'", 'data:'], objectSrc: ["'none'"], frameAncestors: ["'none'"] } } }));
app.use(cors({ origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : false }));
app.use(express.json({ limit: '20kb' }));

app.get('/api/health', (req, res) => res.json({
  ok: true, uptime: process.uptime(),
  db: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected' }));

app.use('/api/enquiries', rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false,
  message: { ok: false, message: 'Too many submissions. Please try again in a few minutes.' } }));
app.use('/api/enquiries', require('./routes/enquiries'));
app.use('/api', (req, res) => res.status(404).json({ ok: false, message: 'Not found.' }));
app.use(express.static(path.join(__dirname, '..', 'public'), { maxAge: '7d', extensions: ['html'] }));

app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ ok: false, message: 'Invalid request.' });
  console.error(err);
  res.status(500).json({ ok: false, message: 'Something went wrong. Please try again later.' });
});

const port = process.env.PORT || 3000;
mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/harbourline')
  .then(() => app.listen(port, () => console.log(`Listening on http://localhost:${port}`)))
  .catch((e) => { console.error('MongoDB connection failed:', e.message); process.exit(1); });
