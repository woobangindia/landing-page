import React, { useState } from 'react';

function NavBar() {
  const [open, setOpen] = useState(false);
  const toggle = () => setOpen(!open);

  const scrollTo = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
    setOpen(false);
  };

  return (
    <nav className="navbar">
      <div className="logo" onClick={() => scrollTo('home')}>CompanyLogo</div>
      <ul className={`nav-links ${open ? 'open' : ''}`}>
        <li onClick={() => scrollTo('home')}>Home</li>
        <li onClick={() => scrollTo('about')}>About</li>
        <li onClick={() => scrollTo('tenants')}>For Tenants</li>
        <li onClick={() => scrollTo('agents')}>For Agents</li>
        <li onClick={() => scrollTo('contact')}>Contact</li>
        <li className="cta" onClick={() => scrollTo('contact')}>Get in Touch</li>
      </ul>
      <div className={`hamburger ${open ? 'open' : ''}`} onClick={toggle} aria-label="Menu" aria-expanded={open}>
        <span></span><span></span><span></span>
      </div>
    </nav>
  );
}

export default NavBar;
