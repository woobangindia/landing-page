import React from 'react';
import NavBar from './components/NavBar';
import Hero from './components/Hero';
import TenantSection from './components/TenantSection';
import AgentSection from './components/AgentSection';
import WhyChooseUs from './components/WhyChooseUs';
import About from './components/About';
import FAQ from './components/FAQ';
import FinalCTA from './components/FinalCTA';
import Footer from './components/Footer';

function App() {
  return (
    <div className="app">
      <NavBar />
      <Hero />
      <TenantSection />
      <AgentSection />
      <WhyChooseUs />
      <About />
      <FAQ />
      <FinalCTA />
      <Footer />
    </div>
  );
}

export default App;
