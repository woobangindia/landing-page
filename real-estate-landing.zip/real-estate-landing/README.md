# Real Estate Landing Page

This is a production‑ready, premium landing page for a UK‑based real estate company.

## Overview
- **Frontend**: React (Vite) – modern, fast, and highly optimizable.
- **Backend**: Node.js + Express – lightweight API for the two enquiry forms.
- **Database**: MongoDB (via Mongoose) – separate schemas for tenant and agent enquiries.
- **Styling**: CSS with the colour palette you specified, DM Sans for body text and Playfair Display for headings.
- **Features**:
  - Sticky responsive navigation with hamburger menu.
  - Smooth scrolling between sections.
  - Fully functional tenant and agent enquiry forms (client‑ and server‑side validation, spam honeypot, loading / success states).
  - Email notification (configurable via `nodemailer`).
  - SEO‑friendly markup, Open Graph tags, robots.txt, sitemap.xml.
  - Accessible HTML structure (ARIA, proper labels, keyboard navigation).

## Project Structure
```
real-estate-landing/
├─ public/                # static assets (robots.txt, sitemap.xml, placeholder images)
├─ src/                   # React source code
│   ├─ components/        # UI components (NavBar, Hero, Forms, etc.)
│   ├─ App.jsx
│   └─ main.jsx
├─ server/                # Express API
│   ├─ models/            # Mongoose schemas
│   ├─ routes/            # API routes
│   └─ index.js           # server entry point
├─ .env.example           # environment variables template
├─ package.json
├─ vite.config.js
└─ index.html             # HTML entry (served by Vite)
```

## Getting Started
1. **Set up the workspace**
   ```bash
   cd /home/aniket923950/.gemini/antigravity/scratch/real-estate-landing
   ```
2. **Install dependencies**
   ```bash
   npm install
   ```
3. **Configure environment**
   - Copy `.env.example` to `.env` and fill in your MongoDB URI and optional email SMTP settings.
4. **Run the development server**
   ```bash
   npm run dev    # starts Vite (frontend) and the Express API concurrently
   ```
   The landing page will be available at `http://localhost:5173` and the API at `http://localhost:3000`.

5. **Build for production**
   ```bash
   npm run build   # builds static assets into `dist/`
   npm start       # starts the Express server serving the built frontend
   ```

## Deployment Tips
- Host the built `dist/` folder on any static‑site CDN (Netlify, Vercel, etc.).
- Keep the Express API on a server with Node support (e.g., Railway, Render, Railway, Render). Ensure the environment variable `MONGODB_URI` points to a secure MongoDB instance.
- Configure a domain and set up HTTPS; the SEO metadata already includes Open Graph tags for social sharing.

## Customisation
- Replace placeholder images in `public/` with real property photos.
- Edit the copy inside the React components (`src/components/*`) – the text is already placed in placeholders where you can insert the final company information.
- Adjust the colour palette or typography by editing `src/styles.css`.

---
**Note**: This repository contains only the landing page and the minimal API required for the enquiry forms. All future application logic (property listings, dashboards, payments, etc.) can be added later without rewriting the landing page.
